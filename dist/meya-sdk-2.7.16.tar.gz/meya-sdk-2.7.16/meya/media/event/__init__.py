from meya.media.event.event import MediaEvent

__all__ = ["MediaEvent"]
