from meya.http.entry.entry import HttpEntry

__all__ = ["HttpEntry"]
