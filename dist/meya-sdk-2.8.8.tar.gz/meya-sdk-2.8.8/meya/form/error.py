class FormValidationError(Exception):
    pass
