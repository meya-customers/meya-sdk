from meya.form.trigger.trigger import FormTrigger

__all__ = ["FormTrigger"]
