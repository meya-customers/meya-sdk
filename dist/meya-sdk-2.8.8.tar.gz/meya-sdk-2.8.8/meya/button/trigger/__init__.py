from meya.button.trigger.trigger import ButtonTrigger

__all__ = ["ButtonTrigger"]
