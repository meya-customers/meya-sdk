from meya.facebook.messenger.integration.integration import (
    FacebookMessengerIntegration,
)

__all__ = ["FacebookMessengerIntegration"]
