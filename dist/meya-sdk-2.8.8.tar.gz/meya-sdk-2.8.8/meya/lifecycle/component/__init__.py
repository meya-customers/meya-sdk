from meya.lifecycle.component.component import LifecycleComponent

__all__ = ["LifecycleComponent"]
