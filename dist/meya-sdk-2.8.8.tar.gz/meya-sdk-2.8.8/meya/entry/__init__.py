from meya.entry.entry import Entry

__all__ = ["Entry"]
