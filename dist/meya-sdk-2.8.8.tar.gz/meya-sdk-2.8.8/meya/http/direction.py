from meya.util.enum import SimpleEnum


class Direction(SimpleEnum):
    RX = "rx"
    TX = "tx"
