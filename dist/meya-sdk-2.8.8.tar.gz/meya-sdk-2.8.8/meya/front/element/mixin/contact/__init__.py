from meya.front.element.mixin.contact.contact import FrontContactMixin

__all__ = ["FrontContactMixin"]
