from meya.front.element.mixin.conversation.conversation import (
    FrontConversationMixin,
)

__all__ = ["FrontConversationMixin"]
