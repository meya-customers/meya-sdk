class TypeRegistryImportError(Exception):
    pass
