from meya.email.component.component import EmailComponent

__all__ = ["EmailComponent"]
