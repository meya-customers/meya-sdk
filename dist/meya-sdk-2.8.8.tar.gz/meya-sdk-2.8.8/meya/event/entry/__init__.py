from meya.event.entry.entry import Event

__all__ = ["Event"]
