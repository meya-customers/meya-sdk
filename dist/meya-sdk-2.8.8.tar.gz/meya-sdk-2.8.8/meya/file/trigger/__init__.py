from meya.file.trigger.trigger import FileTrigger

__all__ = ["FileTrigger"]
