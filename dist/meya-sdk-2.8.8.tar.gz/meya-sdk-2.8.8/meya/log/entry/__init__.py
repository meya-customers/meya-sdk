from meya.log.entry.entry import LogEntry

__all__ = ["LogEntry"]
