from meya.util.enum import SimpleEnum


class Level(SimpleEnum):
    DEBUG = "debug"
    ERROR = "error"
    INFO = "info"
    WARNING = "warning"
