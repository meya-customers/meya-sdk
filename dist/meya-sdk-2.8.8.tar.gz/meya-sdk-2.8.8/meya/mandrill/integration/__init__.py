from meya.mandrill.integration.integration import MandrillIntegration
from meya.mandrill.integration.integration import MandrillIntegrationRef

__all__ = ["MandrillIntegration", "MandrillIntegrationRef"]
