from dataclasses import dataclass
from meya.component.entry import ComponentEntry


@dataclass
class ComponentNextEntry(ComponentEntry):
    pass
