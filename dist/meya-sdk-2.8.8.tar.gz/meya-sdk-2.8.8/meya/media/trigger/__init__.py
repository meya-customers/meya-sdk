from meya.media.trigger.trigger import MediaTrigger

__all__ = ["MediaTrigger"]
