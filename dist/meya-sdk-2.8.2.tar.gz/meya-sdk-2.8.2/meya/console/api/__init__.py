from meya.console.api.api import make_mutation_op
from meya.console.api.api import make_query_op

__all__ = ["make_query_op", "make_mutation_op"]
