from meya.bot.entry.entry import BotEntry

__all__ = ["BotEntry"]
