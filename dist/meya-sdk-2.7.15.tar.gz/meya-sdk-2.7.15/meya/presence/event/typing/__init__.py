from meya.presence.event.typing.typing import TypingEvent

__all__ = ["TypingEvent"]
