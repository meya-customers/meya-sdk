from meya.google.actions.integration.integration import (
    GoogleActionsIntegration,
)

__all__ = ["GoogleActionsIntegration"]
