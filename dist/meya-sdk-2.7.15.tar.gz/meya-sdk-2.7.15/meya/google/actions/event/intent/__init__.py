from meya.google.actions.event.intent.intent import GoogleActionsIntentEvent

__all__ = ["GoogleActionsIntentEvent"]
