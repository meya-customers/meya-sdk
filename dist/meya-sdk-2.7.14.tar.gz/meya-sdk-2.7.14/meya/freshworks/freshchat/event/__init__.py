from meya.freshworks.freshchat.event.event import FreshchatEvent

__all__ = ["FreshchatEvent"]
