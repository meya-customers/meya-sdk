class MetaLevel:
    HIDDEN = 0.0
    VERY_ADVANCED = 0.1
    ADVANCED = 0.3
    INTERMEDIATE = 0.5
    BASIC = 0.7
    VERY_BASIC = 0.9
    VERY_BASIC_TOP = 0.91
