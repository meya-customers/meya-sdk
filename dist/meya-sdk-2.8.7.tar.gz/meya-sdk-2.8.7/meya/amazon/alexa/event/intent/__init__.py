from meya.amazon.alexa.event.intent.intent import AlexaIntentEvent

__all__ = ["AlexaIntentEvent"]
