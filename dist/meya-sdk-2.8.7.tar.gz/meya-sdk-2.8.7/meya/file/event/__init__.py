from meya.file.event.event import FileEvent

__all__ = ["FileEvent"]
