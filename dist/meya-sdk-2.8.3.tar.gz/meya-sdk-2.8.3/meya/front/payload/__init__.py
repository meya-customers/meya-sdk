from meya.front.payload.payload import FrontPayload

__all__ = ["FrontPayload"]
