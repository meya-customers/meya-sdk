from meya.mailgun.integration.integration import MailgunIntegration
from meya.mailgun.integration.integration import MailgunIntegrationRef

__all__ = ["MailgunIntegration", "MailgunIntegrationRef"]
