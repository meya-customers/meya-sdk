from meya.email.email import Recipient

__all__ = ["Recipient"]
