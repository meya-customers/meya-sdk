from meya.facebook.wit.integration.integration import WitIntegration
from meya.facebook.wit.integration.integration import WitIntegrationRef

__all__ = ["WitIntegration", "WitIntegrationRef"]
