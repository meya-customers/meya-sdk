from meya.component.entry.entry import ComponentEntry

__all__ = ["ComponentEntry"]
