from meya.util.enum import SimpleEnum


class Scope(SimpleEnum):
    BOT = "bot"
    DEVELOPER = "developer"
    SYSTEM = "system"
