from meya.media.event import MediaEvent

__all__ = ["MediaEvent"]
