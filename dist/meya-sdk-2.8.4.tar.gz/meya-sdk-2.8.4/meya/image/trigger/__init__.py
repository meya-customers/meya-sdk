from meya.image.trigger.trigger import ImageTrigger

__all__ = ["ImageTrigger"]
