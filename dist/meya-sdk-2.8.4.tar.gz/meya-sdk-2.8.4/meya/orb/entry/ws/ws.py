from dataclasses import dataclass
from meya.ws.entry import WsEntry


@dataclass
class OrbWsEntry(WsEntry):
    pass
