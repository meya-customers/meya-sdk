from meya.front.element.mixin.contact.handle.handle import FrontHandleMixin

__all__ = ["FrontHandleMixin"]
