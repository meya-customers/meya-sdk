from meya.util.enum import SimpleEnum


class Phase(SimpleEnum):
    LOAD_APP = "load_app"
    PROCESS_ENTRY = "process_entry"
