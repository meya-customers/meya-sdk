from meya.presence.event.event import PresenceEvent

__all__ = ["PresenceEvent"]
