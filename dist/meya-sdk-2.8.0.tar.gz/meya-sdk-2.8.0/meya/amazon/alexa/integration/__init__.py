from meya.amazon.alexa.integration.integration import AlexaIntegration

__all__ = ["AlexaIntegration"]
