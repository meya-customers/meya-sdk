from meya.orb.entry.ws.ws import OrbWsEntry

__all__ = ["OrbWsEntry"]
