from meya.file.component.component import FileComponent

__all__ = ["FileComponent"]
