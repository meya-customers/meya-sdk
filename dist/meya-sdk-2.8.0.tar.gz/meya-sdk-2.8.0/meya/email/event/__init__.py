from meya.email.event.event import EmailEvent

__all__ = ["EmailEvent"]
