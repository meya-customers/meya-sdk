# Meya SDK
Welcome to the Meya SDK! 

First a bit of context about the Meya SDK. The Meya SDK is 
implemented using async Python 3.
This provides a development environment that is friendly for new developers, productive for experienced devs, and it runs fast at scale to process customer requests.

All the code in this repo is available to use in your app at runtime when deployed to the Meya chatbot platform.

## Getting started
The following guides will help you get started building and launching your very own Meya app.

- [Getting started](https://docs.meya.ai/docs)
- [Elements & Entries](https://docs.meya.ai/docs/elements-and-entries)
- [Components](https://docs.meya.ai/docs/components-1)
